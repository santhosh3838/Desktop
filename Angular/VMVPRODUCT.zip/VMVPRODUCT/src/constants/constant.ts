export const Constant={
    API_END_POINT:{
        ADD_NEW_HOSPITAL:'AddNewHospital',
        Login:'Login',
        addNewAppointment:'AddNewAppointment'
    }
}