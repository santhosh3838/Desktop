
export const environment = {
api_url:'https://freeapi.gerasim.in/api/Practo/'
    
}  