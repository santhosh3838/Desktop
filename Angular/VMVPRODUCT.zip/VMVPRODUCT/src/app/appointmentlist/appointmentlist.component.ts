import { Component, inject } from '@angular/core';
import { ApiResponseModel, NewAppointment } from '../../core/classes/Hospital';
import { FormsModule } from '@angular/forms';
import {  AppointmentService} from '../services/appointment.service';

@Component({
  selector: 'app-appointmentlist',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './appointmentlist.component.html',
  styleUrl: './appointmentlist.component.css'
})
export class AppointmentlistComponent {
  newappointment: NewAppointment=new NewAppointment();

// constructor(private appointservice:AppointmentService){

// }  or
appointserv= inject(AppointmentService);

constructor() {
  const loggedata = localStorage.getItem('practologin');
  if (loggedata != null) {
   this.newappointment.hospitalId=JSON.parse(loggedata).hospitalId;
  }
}

bookAppointMent(){
  debugger
  this.appointserv.NewAppointment(this.newappointment).subscribe((res:ApiResponseModel)=>
  {
    if(res.result)
    {
alert('Appointment Created')
    }else{
      alert(res.message)
    }
  })
}

}
