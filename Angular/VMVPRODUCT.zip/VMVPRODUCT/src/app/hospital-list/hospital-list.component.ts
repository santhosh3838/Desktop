import { Component } from '@angular/core';

@Component({
  selector: 'app-hospital-list',
  standalone: true,
  imports: [],
  templateUrl: './hospital-list.component.html',
  styleUrl: './hospital-list.component.css'
})
export class HospitalListComponent {

}
